package com.example.gui;

public class ChatIndController {
}
